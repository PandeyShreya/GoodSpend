package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.anychart.enums.Align;
import com.anychart.enums.LegendLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChartActivity extends AppCompatActivity {
    BottomNavigationView nav_view;
    AnyChartView anyChartView;
    private String onlineUserID;
    private DatabaseReference expensesRef;
    FirebaseAuth firebaseAuth;

    private  int totalGroceryAmount = 0, totalEntertainmentAmount = 0, totalKidsAmount = 0, totalSavingsAmount = 0,
            totalShoppingAmount = 0, totalBillsAmount = 0, totalTravelAmount = 0, totalVehicleAmount = 0,
            totalFuelsAmount = 0, totalMedicalAmount = 0, totalEatingOutAmount = 0, totalOthersAmount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);

        anyChartView = findViewById(R.id.any_chart_view);

        firebaseAuth = FirebaseAuth.getInstance();
        onlineUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        expensesRef = FirebaseDatabase.getInstance().getReference("expenses").child(onlineUserID);

        expensesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists() && snapshot.getChildrenCount()>0){
                    for(DataSnapshot ds : snapshot.getChildren()){
                        Map<String, Object> map = (Map<String, Object>)ds.getValue();
                        Object Category = map.get("expense_category");
                        String expenseCategory = String.valueOf(Category);

                        if(expenseCategory.equals("Grocery")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalGroceryAmount += pAmount;
                        }
                        else if(expenseCategory.equals("Entertainment")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalEntertainmentAmount += pAmount;
                        }
                        else if(expenseCategory.equals("Kids")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalKidsAmount += pAmount;
                        }
                        else if(expenseCategory.equals("Savings/Investment")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalSavingsAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Shopping")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalShoppingAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Bills")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalBillsAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Travel")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalTravelAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Vehicle")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalVehicleAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Fuels")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalFuelsAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Medical")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalMedicalAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Eating Out")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalEatingOutAmount+= pAmount;
                        }
                        else if(expenseCategory.equals("Others")){
                            Object Amount = map.get("amount");
                            int pAmount = Integer.parseInt(String.valueOf(Amount));
                            totalOthersAmount+= pAmount;
                        }
                        Pie pie = AnyChart.pie();

                        List<DataEntry> data = new ArrayList<>();
                        data.add(new ValueDataEntry("Grocery", totalGroceryAmount));
                        data.add(new ValueDataEntry("Entertainment", totalEntertainmentAmount));
                        data.add(new ValueDataEntry("Kids", totalKidsAmount));
                        data.add(new ValueDataEntry("Savings/Investment", totalSavingsAmount));
                        data.add(new ValueDataEntry("Shopping", totalShoppingAmount));
                        data.add(new ValueDataEntry("Bills", totalBillsAmount));
                        data.add(new ValueDataEntry("Travel", totalTravelAmount));
                        data.add(new ValueDataEntry("Vehicle", totalVehicleAmount));
                        data.add(new ValueDataEntry("Fuels", totalFuelsAmount));
                        data.add(new ValueDataEntry("Medical", totalMedicalAmount));
                        data.add(new ValueDataEntry("Eating Out", totalEatingOutAmount));
                        data.add(new ValueDataEntry("Others", totalOthersAmount));

//                        anyChartView.setBackgroundColor(Color.GREEN);
//                        anyChartView.setBackground(android.graphics.drawable.shapes.OvalShape);
                        pie.data(data);
                        pie.title("Expense Data");

                        pie.labels().position("outside");

                        pie.legend().title().enabled(true);
                        pie.legend().title()
                                .text("Items Spent on")
                                .padding(0d, 0d, 10d, 0d);

                        pie.legend()
                                .position("center-bottom")
                                .itemsLayout(LegendLayout.HORIZONTAL)
                                .align(Align.CENTER);

                        anyChartView.setChart(pie);

                    }

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



//        data.add(new ValueDataEntry("One", 10000));
//        data.add(new ValueDataEntry("Two", 500));
//        data.add(new ValueDataEntry("Three",20000));
//        data.add(new ValueDataEntry("Four", 3000));


        nav_view = findViewById(R.id.nav_view);
        nav_view.setSelectedItemId(R.id.navigation_chartview);
        nav_view.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.navigation_transactions:
                        startActivity(new Intent(getApplicationContext(),TransactionActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_home:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_chartview:
                        return true;
                    case R.id.navigation_alerts:
                        startActivity(new Intent(getApplicationContext(),AlertsActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_autoadd:
                        startActivity(new Intent(getApplicationContext(),AutopayHome.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return  false;
            }
        });
    }


}